/**********************************************************
EDIT ONLY THIS FILE & SUBMIT TO DROPBOX
Use '**** INSERT CODE HERE ****' to guide edit placements

PERSONALIZE your source code (place inside the <angle> brackets)
Blinn Username: <BLINN.USERNAME>
Assignment: "Lab 4 How Large Is the U.S. Capitol Building?"
Course: COSC 1420
Section: <???> (N01 or N02)
Due Date: Friday, March 1, 2024
**********************************************************/

#include <stdio.h>
#include <string.h>

// Function 'readData':
// 1. use 'str' for input prompt
// 2. read data from 'file'
// 3. return read 'value'
double readData(char *str, FILE *file)
{
    double value = 1;

    // Input prompt
    // **** INSERT CODE HERE ****


    // Input value
    // **** INSERT CODE HERE ****


    // Output string value (without newline)
    // Set for fixed decimal, four (4) decimal places
    // **** INSERT CODE HERE ****


    return value;
}

// Function 'inputline': read a line into 'str', return length
// Note: Value of string 'str' will be passed to 'monument' variable
// Note: Remove newline ('\n') from file input stream
void readName(char *str, int SIZE, FILE *file)
{
    // Input prompt
    printf("The NAME of the Federal Monument: ");

    // 1. Remove newline ('\n') from file input stream
    // 2. Input string value (may be multiple words)
    // **** INSERT CODE HERE ****


    // Output inputted string value
    printf("%s", str);
}

// converts the distance to inches
// 1 m = 39.3700787 in
double total_in_inches(double size_in_meters)
{
    double total_inches = 0;
    // **** INSERT CODE HERE ****


    return total_inches;
}

// 'size':  height or diameter in inches
// 'scale': factor for reducing 'size'
double scale_inches(double size, double scale)
{
    double scaled_size = 0;
    // **** INSERT CODE HERE ****


    return scaled_size;
}

// find number of whole feet from inches
// use: 2.54 centimeters per inch for conversion factor
int find_feet(double inches)
{
    int feet = 0;
    // **** INSERT CODE HERE ****


    return feet;
}

// find extra number of inches after number of feet deducted
double find_inches(double inches)
{
    double remaining_inches = 0;
    // **** INSERT CODE HERE ****
    

    return remaining_inches;
}
